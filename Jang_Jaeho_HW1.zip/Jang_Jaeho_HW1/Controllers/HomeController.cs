﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace Jang_Jaeho_HW1.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment _environment;
        
        public HomeController(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        public IActionResult ReturnAFile()
        {
            string path = _environment.WebRootPath + "/files/Jaeho_Jang_Resume_MIS333K.pdf";
            var stream = new FileStream(path, FileMode.Open);
            return File(stream, "application/pdf", "Jaeho_Jang_Resume_MIS333K.pdf");
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult MoreAbout()
        {
            return View();
        }

        public IActionResult ProfAbout()
        {
            return View();
        }
    }
}
