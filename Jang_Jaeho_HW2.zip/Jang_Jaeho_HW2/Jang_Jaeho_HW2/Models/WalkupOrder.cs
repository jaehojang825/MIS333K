﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace Jang_Jaeho_HW2.Models
{
    //child class of order class
    public class WalkupOrder : Order
    {
        //declares constant tax rate
        const Decimal SALES_TAX_RATE = 0.0875m;

        //declares customer name variable
        public String CustomerName { get; set; }
        
        //declares sales tax variable with annotation
        [DisplayFormat(DataFormatString ="{0:c}")]
        public Decimal SalesTax { get; set; }

        //method to calculate sales tax and total
        public void CalcTotals()
        {
            CalcSubtotals();

            SalesTax = Subtotal * SALES_TAX_RATE;
            Total = Subtotal + SalesTax;

        }
    }
}
