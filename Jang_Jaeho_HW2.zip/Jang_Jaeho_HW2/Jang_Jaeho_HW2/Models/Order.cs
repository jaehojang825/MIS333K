﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography.X509Certificates;
using Jang_Jaeho_HW2.Models;

namespace Jang_Jaeho_HW2.Models
{
    //enumerates the two type of customers
    public enum CustomerTypes {Walkup, Wholesale }

    //parent order class (abstract)
    public abstract class Order
    {
        //constant variables for two prices
        const Decimal HARDBACK_PRICE = 19.0m;
        const Decimal PAPERBACK_PRICE = 7.0m;

        //declares customer type variable
        [Display(Name ="Customer Type")]
        public CustomerTypes CustomerType { get;set; }

        //declares number of hardbacks variable with annotations
        [Display(Name = "Number of Hardbacks")]
        [Required(ErrorMessage ="Select a number of hardbacks.")]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter only numbers.")]
        public Int32 NumberOfHardbacks { get; set; }

        //declares number of paperback variables with annotations
        [Display(Name = "Number of Paperbacks")]
        [Required(ErrorMessage = "Select a number of hardbacks.")]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter only numbers.")]
        public Int32 NumberOfPaperbacks { get; set; }

        //declares hardback subtotal variable with annotations
        [Display(Name = "Hardback Subtotal")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal HardbackSubtotal { get; set; }

        //declares paperback subtotal variable with annotations
        [Display(Name = "Paperback Subtotal")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal PaperbackSubtotal { get; set; }

        //declares subtotal variables witih annotations
        [Display(Name = "Subtotal")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Subtotal { get; set; }

        //declares total items variables
        [Display(Name = "Total Items")]
        public Int32 TotalItems { get; set; }

        //declares total variable with annotations
        [Display(Name = "Total")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Total { get; set; }
        
        //creates method to calculate hardback subtotal, paperback subtotal, subtotal, and total items
        public void CalcSubtotals()
        {
            HardbackSubtotal = NumberOfHardbacks * HARDBACK_PRICE;
            PaperbackSubtotal = NumberOfPaperbacks * PAPERBACK_PRICE;
            Subtotal = HardbackSubtotal + PaperbackSubtotal;
            TotalItems = NumberOfHardbacks + NumberOfPaperbacks;
        }
    }
}
