﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Jang_Jaeho_HW2.Models
{
    //child class of order class
    public class WholesaleOrder : Order
    {
        //declares customer code variable with annotations
        [Display(Name = "Customer Code")]
        [Required(ErrorMessage ="Please enter a valid input.")]
        [StringLength(4, MinimumLength = 2, ErrorMessage = "Customer code must be between 2-4 letters.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Please enter only letters.")] 
        public String CustomerCode { get; set; }

        //declares delivery fee variable with annotations
        [Display(Name = "Delivery Fee")]
        [Range(0,175,ErrorMessage ="Delivery fee must be between 0 - 175.")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal DeliveryFee { get; set; }

        //declares preferred customer variable
        [Display(Name = "Preferred Customer?")]
        public Boolean PreferredCustomer { get; set; }

        //methods to calculate subtotals with delivery fee accounted
        public void CalcTotals(decimal decDeliveryFee)
        {
            CalcSubtotals();
            DeliveryFee = decDeliveryFee;
            //delivery fee = 0 if preferred customer
            if (PreferredCustomer==true)
            {
                DeliveryFee = 0;
            }
            Total = Subtotal + DeliveryFee;
        }
    }
}
