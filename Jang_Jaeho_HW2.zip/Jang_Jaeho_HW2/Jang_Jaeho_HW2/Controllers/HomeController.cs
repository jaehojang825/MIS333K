﻿//Author: Jaeho Jang
//Date: 09/25/20
//Assginment: Homework 2

using Microsoft.AspNetCore.Mvc;
using Jang_Jaeho_HW2.Models;

namespace Jang_Jaeho_HW2.Controllers
{
    public class HomeController : Controller
    {
        //the index view
        public IActionResult Index()
        {
            return View();
        }

        //creates view to retreive data for walk up orders
        [HttpGet]
        public IActionResult CheckoutWalkup()
        {
            return View("CheckoutWalkup");
        }

        //creates view to display retreived walk up orders
        [HttpGet]
        public IActionResult WalkupTotal(WalkupOrder walkupOrder)
        {
            //annotation; validation
            TryValidateModel(walkupOrder);

            if (ModelState.IsValid==false)
            {
                return View("CheckoutWalkup");

            }
            //sets customer type = walk up
            walkupOrder.CustomerType = CustomerTypes.Walkup;

            //calculates total for walk up
            walkupOrder.CalcTotals();

            //returs final view for walk up totals
            return View("WalkupTotal", walkupOrder);
        }

        //creates view to retreive data for wholesale orders
        [HttpGet]
        public IActionResult CheckoutWholesale()
        {
            return View("CheckoutWholesale");
        }

        //creates view to display retreived walk up order
        [HttpGet]
        public IActionResult WholesaleTotals(WholesaleOrder wholesaleOrder)
        {
            //annotation; validation
            TryValidateModel(wholesaleOrder);

            if (ModelState.IsValid==false)
            {
                return View("CheckoutWholesale");
            }
            //sets customer type = wholesale
            wholesaleOrder.CustomerType = CustomerTypes.Wholesale;

            //calculates total for wholesale orders with delivery fees accounted
            wholesaleOrder.CalcTotals(wholesaleOrder.DeliveryFee);

            //final views for wholesale orders
            return View("WholesaleTotals", wholesaleOrder);
        }

        
    }
}
